from django.apps import AppConfig


class TherapistConfig(AppConfig):
    name = 'therapist'
