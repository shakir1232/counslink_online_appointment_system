from django.contrib import messages
from django.contrib.auth import logout, login, authenticate
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.views.generic.base import View
from django.urls import reverse
from django.http import HttpResponseRedirect
from django.shortcuts import redirect


def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        print(User.objects.filter(username=username, password=password).values('username'))
        print(username)
        try:
            get_user = User.objects.get(username=username)
        except:
            get_user = None
        if get_user is not None:
            # user = User.objects.get(username=username, password=password)
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                print('loggedin')
                url = request.GET.get("next")
                if url is not None or url != '':
                    return HttpResponseRedirect(url)
                else:  # Make sure the url comes from your project
                    return redirect('home')
            else:
                messages.error(request, 'Password is incorrect')
                return render(request, 'login.html')

        else:
            messages.error(request, 'User not found!')
            return render(request, 'login.html')

    else:
        url = request.GET.get("next")
        print(url)
        if request.user.is_authenticated:
            print('already')
            if url is not None:
                return HttpResponseRedirect(url)
            else:  # Make sure the url comes from your project
                return redirect('home')
        return render(request, 'login.html', {'url':url})


def user_logout(request):
    logout(request)
    url = request.GET.get("next")
    if url is not None:
        return HttpResponseRedirect(url)
    else:  # Make sure the url comes from your project
        return redirect('home')


class HomeView(View):
    template_name = 'index.html'

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name, )


class AboutView(View):
    template_name = 'about.html'

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name, )


class CustomerView(View):
    template_name = 'customer.html'

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name, )


class CustomerAccountView(View):
    template_name = 'customeraccount.html'

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name, )


class TherapistView(View):
    template_name = 'therapist.html'

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name, )


class CustomerSignUpView(View):
    template_name = 'sign-up.html'

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name, )


class TherapistSignUptView(View):
    template_name = 'therapistsignup.html'

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name, )


class SignInView(View):
    template_name = 'login.html'

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name, locals())


class TherapistDetailsView(View):
    template_name = 'therapist-details.html'

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name, )
