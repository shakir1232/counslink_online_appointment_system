from django.contrib.auth.models import User
from django.db import models


# Create your models here.

class Customer(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=120)
    zip_code = models.CharField(max_length=50)
    address = models.CharField(max_length=200)
    phone = models.CharField(max_length=20)


class Therapist(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=120)
    zip_code = models.CharField(max_length=50)
    address = models.CharField(max_length=200)
    phone = models.CharField(max_length=20)
    website_link = models.CharField(max_length=128)
    practice = models.CharField(max_length=128)
    importance = models.ManyToManyField('Importance')
    years_of_experience = models.IntegerField()
    Certifications = models.TextField(max_length=500)


class Importance(models.Model):
    option = models.CharField(max_length=200)


class Appointment(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.SET('Unknown'))
    therapist = models.ForeignKey(Therapist, on_delete=models.SET('Unknown'))
    date = models.DateField()
    time = models.TimeField()
    appointment_created = models.DateTimeField(auto_now_add=True)

class Contact(models.Model):
    name = models.CharField(max_length=128)
    phone = models.CharField(max_length=20)
    email = models.EmailField(max_length=60)
    subject = models.CharField(max_length=200)
    message = models.TextField()