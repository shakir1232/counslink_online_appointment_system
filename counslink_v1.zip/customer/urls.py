


from django.urls import path, include
from customer import views

urlpatterns = [
    path('', views.HomeView.as_view(), name = 'home'),
    path('about/', views.AboutView.as_view()),
    path('customer/', views.CustomerView.as_view()),
    path('therapist/', views.TherapistView.as_view()),
    path('customer-account/<id>/', views.CustomerAccountView.as_view()),
    path('customer-signup/', views.CustomerSignUpView.as_view()),
    path('therapist-signup/', views.TherapistSignUptView.as_view()),
    # path('signin/', views.SignInView.as_view(), name = 'signin'),
    path('therapist-details/<id>/', views.TherapistDetailsView.as_view()),
    path('user-login/', views.user_login, name = 'user_login'),
    path('user-logout/', views.user_logout, name = 'user_logout'),
]